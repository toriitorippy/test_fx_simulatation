from .history import InstrumentsCandlesFactory

__all__ = (
    'InstrumentsCandlesFactory',
)
