import fx_init

def lambda_handler(event, context):
    # TODO implement
    fx_init.do_fx()